package com.jNd.manageshop;

import java.awt.event.*;
import java.sql.*;

import javax.swing.*;

import org.sqlite.SQLiteConfig;
import java.awt.Font;
import java.awt.Color;

@SuppressWarnings("serial")
public class ManageShoppingMall_Login extends JFrame{
	
	private Connection connection; 
	
	private JPanel loginPanel;
	private JLabel msg;
	private JLabel idM;
	private JLabel pwM;
	private JTextField id;
	private JPasswordField pw;
	private JButton login;
	public String userID="missingno";
	private JLabel lblNewLabel;
	
	public ManageShoppingMall_Login() {
		setTitle("로그인 하십시오");
		setSize(400,300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		loginPanel = new JPanel();
		loginPanel.setLayout(null);
		msg = new JLabel("로그인하여 서비스를 이용해 주십시오.");
		msg.setBounds(100,58,200,20);
		loginPanel.add(msg);
		idM = new JLabel("아이디:");
		idM.setBounds(75, 88, 400, 20);
		loginPanel.add(idM);
		id = new JTextField(20);
		id.setBounds(125,88,200,20);
		loginPanel.add(id);
		pwM = new JLabel("비밀번호:");
		pwM.setBounds(75, 118, 400, 20);
		loginPanel.add(pwM);
		pw = new JPasswordField(20);
		pw.setEchoChar('*');
		pw.setBounds(125, 118, 200, 20);
		loginPanel.add(pw);
		login = new JButton("로그인");
		login.setBounds(52, 150, 150, 25);
		login.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == login) {
					try {
						lblNewLabel.hide();
						Class.forName("org.sqlite.JDBC");
						SQLiteConfig conf = new SQLiteConfig();
						conf.setReadOnly(false);
						connection = DriverManager.getConnection("jdbc:sqlite:ShoppingMall.db", conf.toProperties());
						//System.out.println("Connection successful");
						String sql = "SELECT PASSWORD FROM CUSTOMER_TABLE WHERE ID=\""+id.getText()+"\";";
						PreparedStatement q = connection.prepareStatement(sql);
						//System.out.println(sql);
						ResultSet result = q.executeQuery(); 
						if(result.next()) {
							//System.out.println("ins");
							String password=result.getString("PASSWORD");
							//System.out.println(pw.getPassword());
							//System.out.println(password.toCharArray());
							if(pw.getText().indexOf(password)==0) userID = id.getText();
							else lblNewLabel.show();
							//System.out.println(userID);
						}
						else {
							userID = "missingno";
							lblNewLabel.show();
						}
						result.close(); 
						q.close();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} finally {
						//System.out.println("Login button has been pressed.");
					}
				}
			}
		});
		loginPanel.add(login);
		
		getContentPane().add(loginPanel);
		
		lblNewLabel = new JLabel("FAILED TO LOGIN!");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 17));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(125, 185, 150, 16);
		lblNewLabel.setVisible(false);
		loginPanel.add(lblNewLabel);
		
		JButton button = new JButton("회원가입");
		button.setBounds(214, 150, 150, 29);
		loginPanel.add(button);
		setVisible(true);
	}
	public String getID() {
		//System.out.println(userID);
		return userID;
	}
}
