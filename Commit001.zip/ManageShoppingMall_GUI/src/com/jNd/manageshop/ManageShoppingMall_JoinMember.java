package com.jNd.manageshop;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;

@SuppressWarnings("serial")
public class ManageShoppingMall_JoinMember extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtPw;
	private JTextField txtAddress;
	private JTextField txtCardNumber;
	private JTextField txtBirth;
	private JTextField txtPhone;
	public String ret;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageShoppingMall_JoinMember frame = new ManageShoppingMall_JoinMember();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageShoppingMall_JoinMember() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("회원가입에 필요한 정보를 입력해 주십시오.");
		label.setBounds(105, 42, 267, 20);
		contentPane.add(label);
		
		txtId = new JTextField();
		txtId.setText("ID");
		txtId.setBounds(68, 70, 130, 26);
		contentPane.add(txtId);
		txtId.setColumns(10);
		
		txtPw = new JTextField();
		txtPw.setText("PW");
		txtPw.setBounds(215, 70, 130, 26);
		contentPane.add(txtPw);
		txtPw.setColumns(10);
		
		txtAddress = new JTextField();
		txtAddress.setText("Address");
		txtAddress.setBounds(68, 108, 277, 26);
		contentPane.add(txtAddress);
		txtAddress.setColumns(10);
		
		txtCardNumber = new JTextField();
		txtCardNumber.setText("Card number");
		txtCardNumber.setColumns(10);
		txtCardNumber.setBounds(68, 146, 277, 26);
		contentPane.add(txtCardNumber);
		
		txtBirth = new JTextField();
		txtBirth.setText("Birth");
		txtBirth.setBounds(68, 186, 98, 26);
		contentPane.add(txtBirth);
		txtBirth.setColumns(10);
		
		txtPhone = new JTextField();
		txtPhone.setText("Phone");
		txtPhone.setBounds(178, 186, 167, 26);
		contentPane.add(txtPhone);
		txtPhone.setColumns(10);
		
		JButton button = new JButton("회원가입");
		button.setBounds(128, 224, 117, 29);
		contentPane.add(button);
	}
}
