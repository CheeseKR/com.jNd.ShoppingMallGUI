package com.jNd.manageshop;

public class ManageShoppingMall_GUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ManageShoppingMall_Login loginFrame = new ManageShoppingMall_Login();
		String ID;
		while(true) {
			System.out.print(""); //뭔가를 계속 해주어야 함
			if(loginFrame.userID!="missingno") {
				break;
			}
		}
		ID = loginFrame.getID();
		System.out.println(ID);
		loginFrame.dispose();
		if(ID == "jmnewmember") {
			ManageShoppingMall_JoinMember joinFrame = new ManageShoppingMall_JoinMember();
			while(true) {
				System.out.print(""); //뭔가를 계속 해주어야 함
				if(joinFrame.ret=="gotit")
			}
		}
		else {
			ManageShoppingMall_Main mainFrame = new ManageShoppingMall_Main(ID);
		}
	}

}
