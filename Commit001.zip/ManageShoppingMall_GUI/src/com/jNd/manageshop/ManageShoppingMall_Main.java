package com.jNd.manageshop;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.sqlite.SQLiteConfig;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.ImageIcon;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.UIManager;

public class ManageShoppingMall_Main extends JFrame {

	private JPanel contentPane;
	public String id;

	/**
	 * Create the frame.
	 */
	public ManageShoppingMall_Main(String I) {
		id = I;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblJavaxSwing = new JLabel("JavaX Swing의 즐거운 쇼핑몰~");
		lblJavaxSwing.setHorizontalAlignment(SwingConstants.CENTER);
		lblJavaxSwing.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 20));
		lblJavaxSwing.setBounds(54, 6, 340, 32);
		contentPane.add(lblJavaxSwing);
		
		JButton button = new JButton("로그아웃");
		button.setBounds(17, 39, 88, 29);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				id = "missingno";
			}
		});
		contentPane.add(button);
		
		JButton button_1 = new JButton("회원 탈퇴");
		button_1.setBounds(101, 39, 97, 29);
		contentPane.add(button_1);
		
		JButton btnNewButton = new JButton("내 주문 확인하기");
		btnNewButton.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		btnNewButton.setIcon(new ImageIcon(ManageShoppingMall_Main.class.getResource("/com/sun/java/swing/plaf/windows/icons/DetailsView.gif")));
		btnNewButton.setBounds(27, 80, 195, 44);
		contentPane.add(btnNewButton);
		
		JButton button_2 = new JButton("상품 주문하기");
		button_2.setIcon(new ImageIcon(ManageShoppingMall_Main.class.getResource("/com/sun/java/swing/plaf/windows/icons/HomeFolder.gif")));
		button_2.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		button_2.setBounds(27, 168, 195, 44);
		contentPane.add(button_2);
		
		JLabel lblId = new JLabel("ID : "+id);
		lblId.setBounds(239, 44, 187, 16);
		contentPane.add(lblId);
		setVisible(true);
	}
}
