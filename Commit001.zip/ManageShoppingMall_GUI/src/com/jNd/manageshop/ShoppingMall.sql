-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE="+00:00" */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE="NO_AUTO_VALUE_ON_ZERO" */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table "CARD_TABLE"
--

DROP TABLE IF EXISTS "CARD_TABLE";
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE "CARD_TABLE" (
  "CARD" varchar(25) DEFAULT NULL,
  "MAKER" varchar(25) DEFAULT NULL,
  "PAID_MONEY" int(11) DEFAULT NULL,
  "NAME" varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table "CARD_TABLE"
--

LOCK TABLES "CARD_TABLE" WRITE;
/*!40000 ALTER TABLE "CARD_TABLE" DISABLE KEYS */;
INSERT INTO "CARD_TABLE" VALUES ("7493649376937799-845","신한카드",261218,"오혜지"),("1111222233334444-567","OO카드",3485000,"심재민"),("9999888877776666-543","XX카드",100000,"선생님"),("1234567890123456-789","ㅁㅁ카드",10000,"강니엘"),("9876543210987654-321","XX카드",500000,"hello");
/*!40000 ALTER TABLE "CARD_TABLE" ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table "CUSTOMER_TABLE"
--

DROP TABLE IF EXISTS "CUSTOMER_TABLE";
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE "CUSTOMER_TABLE" (
  "ID" varchar(20) DEFAULT NULL,
  "NAME" varchar(20) DEFAULT NULL,
  "RATING" varchar(15) DEFAULT NULL,
  "POINTS" int(11) DEFAULT NULL,
  "PHONE" varchar(18) DEFAULT NULL,
  "ADDRESS" varchar(76) DEFAULT NULL,
  "BIRTH" text,
  "PASSWORD" varchar(20) DEFAULT NULL,
  "CARD" varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table "CUSTOMER_TABLE"
--

LOCK TABLES "CUSTOMER_TABLE" WRITE;
/*!40000 ALTER TABLE "CUSTOMER_TABLE" DISABLE KEYS */;
INSERT INTO "CUSTOMER_TABLE" VALUES ("ohange","오혜지","great",130228,"821012345678","some address","","ohyeji0517","7493649376937799-845"),("ch9473","심재민","bronze",206360,"821022739473","some address","","crazy0412","1111222233334444-567"),("teacher777","선생님","silver",60000,"821048593658","some address","","iamgreat","9999888877776666-543"),("wannathree","강니엘","gold",100000,"821074635646","some address","","kangnielle","1234567890123456-789"),("new","hello","default",0,"821033333333","X","","newnew1234","9876543210987654-321");
/*!40000 ALTER TABLE "CUSTOMER_TABLE" ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table "ORDERS_TABLE"
--

DROP TABLE IF EXISTS "ORDERS_TABLE";
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE "ORDERS_TABLE" (
  "ORDER_NUMBER" int(11) DEFAULT NULL,
  "ID" varchar(20) DEFAULT NULL,
  "NAME" varchar(20) DEFAULT NULL,
  "QUANTITY" int(11) DEFAULT NULL,
  "UNITPRICE" int(11) DEFAULT NULL,
  "DISCOUNT" int(11) DEFAULT NULL,
  "ORDER_DATE" text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table "ORDERS_TABLE"
--

LOCK TABLES "ORDERS_TABLE" WRITE;
/*!40000 ALTER TABLE "ORDERS_TABLE" DISABLE KEYS */;
INSERT INTO "ORDERS_TABLE" VALUES (1943168682,"ohange","맛있는 오렌지",25,25000,25,""),(-183565184,"ch9473","맥북프로 2018년형",1,342000,0,""),(704668873,"teacher777","과자 10개 세트",3,60000,30,""),(829892153,"ohange","화장품 세트",1,189000,45,""),(-1887171079,"wannathree","특별주문 로고 부채",76000,1520000,15,""),(208209660,"ohange","화장품 세트",5,100,0,""),(-450005746,"ohange","맛있는 오렌지",20,20000,0,""),(-521351448,"ch9473","아삭한 사과",10,15000,0,""),(1605883128,"ohange","화장품 세트",20,400,0,""),(-1429069012,"ohange","화장품 세트",50,1000,0,""),(680819632,"ohange","화장품 세트",50,1000,0,"");
/*!40000 ALTER TABLE "ORDERS_TABLE" ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table "PRODUCT_TABLE"
--

DROP TABLE IF EXISTS "PRODUCT_TABLE";
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE "PRODUCT_TABLE" (
  "NAME" varchar(20) DEFAULT NULL,
  "PRODUCT_NUM" int(11) DEFAULT NULL,
  "MADE" varchar(40) DEFAULT NULL,
  "PRICE" int(11) DEFAULT NULL,
  "DISCOUNT" int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table "PRODUCT_TABLE"
--

LOCK TABLES "PRODUCT_TABLE" WRITE;
/*!40000 ALTER TABLE "PRODUCT_TABLE" DISABLE KEYS */;
INSERT INTO "PRODUCT_TABLE" VALUES ("맛있는 오렌지",762698302,"조은과일",1000,0),("특별주문 로고 부채",762698303,"굿즈메이커",20,0),("맥북프로 2018년형",762698304,"Apple Inc.",3420000,0),("과자 10개 세트",762698305,"과자공장",20000,20),("화장품 세트",762698306,"굿즈메이커",20,0),("아삭한 사과",762698307,"조은과일",1500,0);
/*!40000 ALTER TABLE "PRODUCT_TABLE" ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-08 22:56:26
